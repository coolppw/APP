import 'package:flutter_blue/flutter_blue.dart';
import 'package:flutter/material.dart';

class Make extends StatefulWidget{
  @override
  MakeState createState() => new MakeState();
}

class MakeState extends State<Make>{
  @override
  Widget build (BuildContext context){
    return Scaffold(
      appBar: new AppBar(
        title: new Text('学习清单'),
        backgroundColor: Color.fromARGB(255, 119, 136, 213), //设置appbar背景颜色
        centerTitle: true,
      ),
      body: new Center(
        child: new Text('ppw'),
      ),
    );
  }
}

