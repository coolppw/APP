import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'package:imagepick_app/json.dart';

void main() => runApp(MyApp());

var img;

class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Image_pick',
      home: new MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  File _image;
  var url = "http://kaleidoscope.geefunlab.com/gateway.do";

  Future getImage() async {
    var image = await ImagePicker.pickImage(source: ImageSource.gallery);

    setState(() {
      _image = image;
    });
  }

  void upLoad(){
    if (_image == null) return;
    String base64Image = base64Encode(_image.readAsBytesSync());


    http.post(url,body: {
      "img":base64Image,
    }).then((response){
      img = jsonDecode(response.body);
      print(img["imgInfo"]["result"]);
      print(response.body);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Image Picker Example'),
      ),
      body:
      new Container(
        child: new Column(
          children: <Widget>[
            new Expanded(
              flex: 6,
              child: Center(
                child: _image == null
                    ? Text('No image selected.')
                    : Image.file(_image),
              ),
            ),
            new Expanded(
              flex: 1,
                child: new Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    new MaterialButton(
                        child: Icon(Icons.check),
                        onPressed: () {
                          Navigator.push(context,
                              new MaterialPageRoute(builder: (context) => new receive()));
                        }
                    ),
                    new Container(
                      padding: EdgeInsets.only(left: 50.0),
                      child:new MaterialButton(
                        color: Colors.blue,
                        child: Icon(Icons.file_upload),
                        onPressed: () {
                          showDialog<Null>(
                            context: context,
                            barrierDismissible: false,
                            builder: (BuildContext context) {
                              return new AlertDialog(
                                title: new Text('您好：'),
                                content: new SingleChildScrollView(
                                  child: new ListBody(
                                    children: <Widget>[
                                      new Text('正在识别图片，请稍等！'),
                                    ],
                                  ),
                                ),
                                actions: <Widget>[
                                  new FlatButton(
                                    child: new Text('确定'),
                                    onPressed: () {
                                      upLoad();
                                      Navigator.of(context).pop();
                                    },
                                  ),
                                ],
                              );
                            },
                          ).then((val) {
                            print(val);
                          });
                        },
                      ),
                    )
                  ],
                )
            ),
          ],
        ),

      ),
      floatingActionButton: FloatingActionButton(
        onPressed: getImage,
        tooltip: 'Pick Image',
        child: Icon(Icons.add_a_photo),
      ),


    );
  }
}

class receive extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new ListView.builder(
        itemBuilder: (BuildContext context,int index){
          return Card(
            child: new Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text("相似度："+img["imgInfo"]["result"][index]["score"].toString()),
                Text("分类目录："+img["imgInfo"]["result"][index]["root"].toString()),
                Text("百度百科："+img["imgInfo"]["result"][index]["baike_info"].toString()),
                Text("关键字："+img["imgInfo"]["result"][index]["keyword"].toString()),
              ],
            ),
          );
        },
      itemCount: img["imgInfo"]["result"] == null ? 0 : img["imgInfo"]["result"].length,
    );
  }
}

