import 'package:flutter/material.dart';
import 'package:wan_huatong_app/page/app.dart';



void main() => runApp(MyApp());